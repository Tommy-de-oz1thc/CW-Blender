top_100 = [
    "some", "would", "go", "their", "than", "he", "in", "had", "first", "do",
    "find", "see", "make", "was", "been", "you", "an", "they", "by", "her", "that",
    "use", "as", "each", "this", "will", "at", "sound", "many", "one", "then", "so",
    "up", "them", "with", "who", "come", "of", "him", "out", "people", "she", "the",
    "said", "write", "it", "may", "like", "did", "most", "which", "has", "know",
    "your", "have", "my", "to", "how", "could", "I", "were", "way", "long", "call",
    "no", "about", "side", "but", "from", "down", "if", "word", "be", "over", "is",
    "look", "hot", "can", "more", "other", "his", "or", "on", "now", "are", "we", "a",
    "these", "for", "day", "two", "there", "all", "number", "what", "and", "thing",
    "water", "when", "time"
]


