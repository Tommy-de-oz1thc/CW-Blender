letter_5 = [
    "ready", "about", "river", "place", "piece", "might", "wheel", "these", "power", "think",
    "house", "field", "other", "group", "point", "large", "vowel", "plane", "story", "class",
    "drive", "found", "white", "cause", "green", "money", "bring", "write", "until", "thing",
    "could", "shape", "order", "whole", "clear", "round", "table", "front", "carry", "horse",
    "among", "sleep", "voice", "early", "short", "study", "small", "black", "begin", "night",
    "water", "often", "teach", "great", "cover", "paper", "reach", "while", "south", "quick",
    "cross", "since", "those", "check", "their", "plant", "plain", "earth", "start", "press",
    "heard", "there", "every", "learn", "usual", "first", "after", "north", "above", "again",
    "right", "close", "three", "state", "world", "pound", "spell", "final", "laugh", "music",
    "stood", "began", "never", "under", "would", "sound", "build", "light", "young", "watch",
    "which", "stand", "still", "color", "where", "serve", "leave", "force"
]
