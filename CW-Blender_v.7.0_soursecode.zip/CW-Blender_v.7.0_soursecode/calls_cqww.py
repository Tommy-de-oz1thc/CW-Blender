# List of amateur radio call signs
calls_cqww = [
    "W0QU", "DL6FBL", "F5LUW", "W7DPW", "UT7UW", "VA3MM", "K2AAX", "K8GU",
    "LA9TJA", "SA1A", "N7ON", "W8WTS", "VE6TN", "F5RRS", "K0VXU", "DL2EBX",
    "JH2RMU", "K6RFM", "WO8J", "IW0GDC", "AA3SJ", "UW2M", "K4YL", "MM1E",
    "WA3AFS", "N9BMH", "N5WR", "G4APJ", "SM5CUI", "EA3BB", "WD4MUO", "K4RT",
    "K1PNQ", "G0RUZ", "YO2IS", "HB9BJJ", "4Z5BS", "N2ODU", "IU2FGB", "NA6O",
    "VE3STZ", "W8TL", "W8MGJ", "DL2RNF", "JA5NNS", "LZ5N", "AA7JV", "N4LF",
    "NC1T", "KA8IFC", "LA7DFA", "VE2UG", "W0AUS", "7N2UQC", "G3LTF", "AF0S",
    "NR6M", "W7SZ", "W1AO", "DK7BY", "K5ZMS", "K0NE", "W3BBO", "N1KTM"
]


