letter_6 = [
    'differ', 'friend', 'listen', 'follow', 'simple', 'weight', 'little', 'enough', 'father', 'people', 'school', 
    'figure', 'animal', 'wonder', 'family', 'behind', 'direct', 'strong', 'beauty', 'decide', 'should', 'number', 
    'ground', 'common', 'second', 'answer', 'course', 'notice', 'record', 'though', 'govern', 'street', 'always', 
    'island', 'toward', 'center', 'minute', 'travel', 'mother', 'change', 'object', 'before', 'better', 'during', 
    'letter', 'person', 'appear', 'happen'
]
