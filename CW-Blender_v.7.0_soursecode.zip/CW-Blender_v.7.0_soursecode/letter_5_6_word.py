letter_5_6 = [
    'ready', 'about', 'river', 'differ', 'friend', 'place', 'piece', 'might', 'wheel', 'listen', 'these', 'follow', 
    'power', 'think', 'house', 'field', 'other', 'group', 'point', 'simple', 'large', 'vowel', 'weight', 'plane', 
    'story', 'class', 'drive', 'found', 'white', 'cause', 'little', 'enough', 'green', 'money', 'bring', 'write', 
    'until', 'father', 'thing', 'people', 'school', 'figure', 'could', 'shape', 'order', 'whole', 'clear', 'round', 
    'table', 'front', 'animal', 'wonder', 'family', 'carry', 'horse', 'among', 'sleep', 'voice', 'early', 'short', 
    'study', 'behind', 'small', 'direct', 'black', 'begin', 'night', 'water', 'strong', 'beauty', 'decide', 'often', 
    'teach', 'great', 'cover', 'should', 'number', 'ground', 'common', 'paper', 'second', 'reach', 'answer', 'course', 
    'while', 'notice', 'south', 'quick', 'cross', 'since', 'record', 'though', 'those', 'govern', 'check', 'their', 
    'street', 'plant', 'plain', 'earth', 'start', 'always', 'island', 'press', 'heard', 'toward', 'center', 'minute', 
    'there', 'travel', 'every', 'learn', 'usual', 'first', 'after', 'mother', 'north', 'above', 'again', 'right', 
    'change', 'close', 'three', 'state', 'world', 'pound', 'spell', 'object', 'final', 'before', 'laugh', 'better', 
    'music', 'during', 'stood', 'began', 'never', 'under', 'would', 'letter', 'person', 'sound', 'build', 'light', 
    'appear', 'young', 'watch', 'which', 'stand', 'still', 'happen', 'color', 'where', 'serve', 'leave', 'force'
]
